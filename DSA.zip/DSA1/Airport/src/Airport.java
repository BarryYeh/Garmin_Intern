import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.GrahamScan;
import java.lang.Math;
/*
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

 */


class Airport {
    // Output smallest average distance with optimal selection of airport location.

    public double airport(List<int[]> houses) {
        double avgDistance;
        int house_size = houses.size();
        Point2D[] houses_2D = new Point2D[house_size];
        if (house_size == 1 || house_size == 2) avgDistance = 0.0;
        else {
            //houses.forEach((i)
            //int[] house = new int[2];
            //house = houses.get(i);
            for (int i = 0; i < house_size; i++) {
                houses_2D[i] = new Point2D(houses.get(i)[0], houses.get(i)[1]);
            }

            int hull_size = 0;
            GrahamScan convexhull = new GrahamScan(houses_2D);
            Point2D[] hull = new Point2D[house_size];
            for (Point2D s : convexhull.hull()) {
                hull[hull_size] = s;
                hull_size++;
            }
        /*
        while (convexhull.hull().iterator().hasNext()) {
                hull[N] = convexhull.hull().iterator().next();
                if (!convexhull.hull().iterator().hasNext()) break;
                N++;
        }
         */
            double[] dx = new double[hull_size];
            double[] dy = new double[hull_size];
            double[] c = new double[hull_size];
            /* y = a * x + b */
            for (int j = 0; j < hull_size; j++) {
                if (j < hull_size - 1) {
                    dx[j] = hull[j].x() - hull[j + 1].x();
                    dy[j] = hull[j].y() - hull[j + 1].y();
                    c[j] = dx[j] * hull[j].y() - dy[j] * hull[j].x();
                }
                if (j == hull_size - 1) {
                    dx[j] = hull[j].x() - hull[0].x();
                    dy[j] = hull[j].y() - hull[0].y();
                    c[j] = dx[j] * hull[j].y() - dy[j] * hull[j].x();
                }
            }
            //double[][] distance = new double[N][n];
            /*點與直線距離公式*/
            double[] total_distance = new double[hull_size];
            for (int s = 0; s < hull_size; s++) {
                for (int h = 0; h < house_size; h++) {
                    total_distance[s] += Math.abs(dy[s] * houses_2D[h].x() - dx[s] * houses_2D[h].y() + c[s]) / Math.sqrt(dx[s] * dx[s] + dy[s] * dy[s]);
                    //total_distance[s] += distance[s][h];
                }
            }
            Arrays.sort(total_distance);
            avgDistance = total_distance[0] / (double) house_size;
        }
        return avgDistance;
    }


        public static void main(String[] args) {
            //test t = new test(args);

            System.out.println(new Airport().airport(new ArrayList<int[]>() {{
                add(new int[]{0, 0});
                add(new int[]{1, 0});
            }}));

            System.out.println(new Airport().airport(new ArrayList<int[]>() {{
                add(new int[]{0, 0});
                add(new int[]{1, 0});
                add(new int[]{0, 1});
            }}));

            System.out.println(new Airport().airport(new ArrayList<int[]>() {{
                add(new int[]{0, 0});
                add(new int[]{2, 0});
                add(new int[]{0, 2});
                add(new int[]{1, 1});
                add(new int[]{2, 2});
            }}));




        }
    }
/*
class test {
    public test(String[] args) {
        Airport sol = new Airport();
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(args[0])) {
            JSONArray all = (JSONArray) jsonParser.parse(reader);
            for (Object CaseInList : all) {
                JSONArray a = (JSONArray) CaseInList;
                int q_cnt = 0, wa = 0, ac = 0;
                for (Object o : a) {
                    q_cnt++;
                    JSONObject person = (JSONObject) o;
                    JSONArray arg_hou = (JSONArray) person.get("houses");
                    double Answer = (double) person.get("answer");
                    ArrayList<int[]> HOU = new ArrayList<int[]>();
                    double Answer_W = 0;
                    for (int i = 0; i < arg_hou.size(); i++) {
                        String spl = arg_hou.get(i).toString();
                        String fir = "";
                        String sec = "";
                        String[] two = new String[2];
                        two = spl.split(",");
                        fir = two[0].replace("[", "");
                        sec = two[1].replace("]", "");
                        int[] hou = new int[2];
                        hou[0] = Integer.parseInt(fir);
                        hou[1] = Integer.parseInt(sec);
                        HOU.add(hou);
                    }
                    Answer_W = sol.airport(HOU);
                    if (Math.abs(Answer_W - Answer) < 1e-4) {
                        System.out.println(q_cnt + ": AC");
                    } else {
                        wa++;
                        System.out.println(q_cnt + ": WA");
                        System.out.println("your answer : " + Answer_W);
                        System.out.println("true answer : " + Answer);
                    }

                }
                System.out.println("Score: " + (q_cnt - wa) + "/" + q_cnt);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}

 */

