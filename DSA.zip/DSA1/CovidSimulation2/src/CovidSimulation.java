import java.util.Arrays;
import java.util.PriorityQueue;
class Event implements Comparable<Event>{
    int Date;
    int PlanType;
    int[] Info;
    Event(int date, int planType,int[] info){
        this.Date = date;
        this.PlanType = planType;
        //PlanType == 0 -> VirusAttackPlan
        //PlanType == 1 -> TravelOutPlan
        //PlanType == 2 -> TravelInPlan
        this.Info = info;
    }
    public int compareTo(Event that){
        if(this.PlanType == 0) {
            if (this.Date <= that.Date)
                return -1;
            else return 1;
        }
        else if(this.PlanType == 2 && that.PlanType != 0){
            if (this.Date <= that.Date)
                return -1;
            else return 1;
        }
        else {
            if(this.Date < that.Date)
                return -1;
            else if (this.Date > that.Date)
                return 1;
        }
        return 0;
    }
}
class CovidSimulation {
    private final int iNum_of_Cities;
    //City[] City;
    int[] Citizen;
    int[] InfectedDate;
    int[] RecoveryDate;
    int[] MaxRecoveryDate;
    PriorityQueue<Event> eventPQ = new PriorityQueue<Event>();
    CovidSimulation(int[] Num_Of_Citizen) {
        iNum_of_Cities = Num_Of_Citizen.length;
        Citizen = Num_Of_Citizen;
        InfectedDate = new int[iNum_of_Cities];
        RecoveryDate = new int[iNum_of_Cities];
        MaxRecoveryDate = new int[iNum_of_Cities];
        for (int i = 0; i < iNum_of_Cities; i++) {
            InfectedDate[i] = 0;
            RecoveryDate[i] = 0;
            MaxRecoveryDate[i] = 0;
        }
    }
    public boolean InfectedOn(int date, int infectedDate, int recoveryDate){
        return infectedDate != recoveryDate && date <= recoveryDate;
    }
    public void virusAttackPlan(int city, int date){
        eventPQ.add(new Event(date, 0,new int[] {city}));
    }
    public void Attack(Event attack){
        if(!InfectedOn(attack.Date, InfectedDate[attack.Info[0]], RecoveryDate[attack.Info[0]])) {
            InfectedDate[attack.Info[0]] = attack.Date;
            RecoveryDate[attack.Info[0]] = attack.Date + 3;
            MaxRecoveryDate[attack.Info[0]] = attack.Date + 6;
        }
    }
    public void TravelPlan(int NumberOfTraveller, int FromCity, int ToCity, int DateOfDeparture, int DateOfArrival){
         eventPQ.add(new Event(DateOfDeparture, 1,new int[] {FromCity, ToCity, NumberOfTraveller, DateOfArrival}));
    }
    public void TravelOut(Event travelOut){
        Citizen[travelOut.Info[0]] -= travelOut.Info[2];
    }
    public void TravelIn(Event travelIn){
        Citizen[travelIn.Info[1]] += travelIn.Info[2];
        if(InfectedOn(travelIn.Date, travelIn.Info[3], travelIn.Info[4])){
            if(InfectedOn(travelIn.Date, InfectedDate[travelIn.Info[1]], RecoveryDate[travelIn.Info[1]])){
                if(RecoveryDate[travelIn.Info[0]] <= MaxRecoveryDate[travelIn.Info[1]])
                    RecoveryDate[travelIn.Info[1]] = Math.max(RecoveryDate[travelIn.Info[0]],RecoveryDate[travelIn.Info[1]]);
                else //RecoveryDate[travelIn.Info[1]] = MaxRecoveryDate[travelIn.Info[1]];
                    RecoveryDate[travelIn.Info[1]] = MaxRecoveryDate[travelIn.Info[1]];
            }
            else{
                InfectedDate[travelIn.Info[1]] = travelIn.Date;
                RecoveryDate[travelIn.Info[1]] = travelIn.Date + 3;
                MaxRecoveryDate[travelIn.Info[1]] = travelIn.Date + 6;
            }
        }
    }
    public int[] Infected(int date){
        int[] c = new int[iNum_of_Cities];
        for(int i = 0; i < iNum_of_Cities; i++){
            if(InfectedOn(date, InfectedDate[i],RecoveryDate[i])) c[i] = 1;
            else c[i] = 0;
        }
        return c;
    }
    public int CityWithTheMostPatient(int date){
            while (!eventPQ.isEmpty()) {
                if (eventPQ.peek().Date > date) break;
                Event poll = eventPQ.poll();
                if (poll.PlanType == 0) Attack(poll);
                if (poll.PlanType == 1) {
                    TravelOut(poll);
                    eventPQ.add(new Event(poll.Info[3], 2, new int[] {poll.Info[0],poll.Info[1],poll.Info[2],InfectedDate[poll.Info[0]],RecoveryDate[poll.Info[0]]}));
                }
                if (poll.PlanType == 2) TravelIn(poll);
            }
            int max_infectedCity = -1;
            int Num = 0;
        for (int i = 0; i < iNum_of_Cities; i++) {
            if(InfectedOn(date, InfectedDate[i], RecoveryDate[i]) && Num <= Citizen[i]){
                Num = Citizen[i];
                max_infectedCity = i;
            }
        }
            return max_infectedCity;

    }

    public static void main(String[] args) {
        //test t = new test(args);
        CovidSimulation sol = new CovidSimulation(new int[] {11,11, 11, 11, 11});
        sol.virusAttackPlan(0, 1);
        sol.virusAttackPlan(1, 2);
        sol.virusAttackPlan(2, 3);
        sol.virusAttackPlan(3, 4);
        sol.virusAttackPlan(4, 5);
        System.out.println(sol.CityWithTheMostPatient(1) + " on day 1");
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(2) + " on day 2");
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(3));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(4));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(5));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(6));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(7));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(8));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(9));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(10));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(11));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(sol.CityWithTheMostPatient(12));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));

        /*
        CovidSimulation sol = new CovidSimulation(new int[] {10, 100, 15, 25, 10, 13});

        sol.virusAttackPlan(0, 1);
        sol.virusAttackPlan(4, 3);
        sol.TravelPlan(3, 0, 3, 3, 4);
        sol.TravelPlan(3, 4, 0, 3, 4);

        System.out.println(sol.CityWithTheMostPatient(2));
        // output = 0

        sol.virusAttackPlan(5, 5);
        sol.TravelPlan(1, 5, 0, 5, 6);

        System.out.println(sol.CityWithTheMostPatient(4));
        // output = 3
        System.out.println(sol.CityWithTheMostPatient(8));
        // output = 5

        //day 1:{10, 100, 15, 25, 10, 13}
        //infectedList:{1, 0, 0, 0, 0, 0}
        //day 2：{10, 100, 15, 25, 10, 13}
        //infectedList:{1, 0, 0, 0, 0, 0}
        //day 3：{7, 100, 15, 25, 7, 13}
        //infectedList:{1, 0, 0, 0, 1, 0}
        //day 4：{10, 100, 15, 28, 7, 13}
        //infectedList:{1, 0, 0, 1, 1, 0}
        //day 5：{10, 100, 15, 28, 7, 12}
        //infectedList:{1, 0, 0, 1, 1, 1}
        //day 6：{11, 100, 15, 28, 7, 12}
        //infectedList:{1, 0, 0, 1, 1, 1}
        //day 7：{11, 100, 15, 28, 7, 12}
        //infectedList:{1, 0, 0, 1, 0, 1}
        //day 8：{11, 100, 15, 28, 7, 12}
        //infectedList:{0, 0, 0, 0, 0, 1}

         */
        /*
        CovidSimulation sol = new CovidSimulation(new int[] {500, 100, 50, 250});

        sol.virusAttackPlan(0, 3);
        sol.virusAttackPlan(1,1);
        sol.virusAttackPlan(3, 3);
        sol.TravelPlan(200, 0, 3, 1, 5);
        sol.TravelPlan(50, 1, 0, 1, 4);
        sol.TravelPlan(150, 0, 2, 1, 3);
        sol.TravelPlan(50, 3, 2, 1, 2);
        sol.TravelPlan(10, 1, 3, 1, 2);
        sol.TravelPlan(70, 3, 0, 2, 3);
        System.out.println(sol.CityWithTheMostPatient(2));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(Arrays.toString(sol.Infected(2)));

        System.out.println(sol.CityWithTheMostPatient(3));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(Arrays.toString(sol.Infected(3)));

        System.out.println(sol.CityWithTheMostPatient(4));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(Arrays.toString(sol.Infected(4)));
        // output = 0
        System.out.println(sol.CityWithTheMostPatient(5));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(Arrays.toString(sol.Infected(5)));
        // output = 3
        System.out.println(sol.CityWithTheMostPatient(6));
        System.out.println(Arrays.toString(sol.Citizen));
        System.out.println(Arrays.toString(sol.RecoveryDate));
        System.out.println(Arrays.toString(sol.Infected(6)));
        // output = 0

         */
    }
}