/*
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
*/
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

class BoardGame {
    private char[] BG2;
    private int[] Emp;
    private WeightedQuickUnionUF wqf;
    private int H;
    private int W;
    private int count = 0;
    public BoardGame(int h, int w) // create a board of size h*w
    {
        H=h;W=w;
        Emp = new int[H*W];
        wqf = new WeightedQuickUnionUF(H * W);
        BG2 = new char[H*W];
        count = H*W;
    }
    public void putStone(int[] x, int[] y, char stoneType) // put stones of the specified type on the board according to the coordinates
    {
        count -= x.length; //'.'數量
        int temp;
        for (int i = 0; i < x.length; i++) {
            int X = x[i];
            int Y = y[i];
            int index = Y * H + X;
            BG2[index] = stoneType;
            Emp[index] = 4;
            int root = wqf.find(index);
            if(X != 0){//檢查左邊
                if(BG2[index - 1] == 'O' || BG2[index - 1] == 'X') {
                    int root2 = wqf.find(index - 1);
                    Emp[root]--;
                    Emp[root2]--;
                    if (BG2[index - 1] == BG2[index] && root != root2){
                        temp = Emp[root] + Emp[root2];
                        wqf.union(index, index - 1);
                        root = wqf.find(index);
                        Emp[root] = temp;
                    }
                }
            }
            if(X != H - 1){//檢查右邊
                if(BG2[index + 1] == 'O' || BG2[index + 1] == 'X') {
                    int root2 = wqf.find(index + 1);
                    Emp[root]--;
                    Emp[root2]--;
                    if (BG2[index + 1] == BG2[index] && root != root2){
                        temp = Emp[root] + Emp[root2];
                        wqf.union(index, index + 1);
                        root = wqf.find(Y * H + X);
                        Emp[root] = temp;
                    }
                }
            }
            if(Y != 0){
                if(BG2[index - H] == 'O' || BG2[index - H] == 'X') {
                    int root2 = wqf.find(index - H);
                    Emp[root]--;
                    Emp[root2]--;
                    if (BG2[index - H] == BG2[index] && root != root2){
                        temp = Emp[root] + Emp[root2];
                        wqf.union(index, index - H);
                        root = wqf.find(index);
                        Emp[root] = temp;
                    }
                }
            }
            if(Y != W - 1){
                if(BG2[index + H] == 'O' || BG2[index + H] == 'X') {
                    int root2 = wqf.find(index + H);
                    Emp[root]--;
                    Emp[root2]--;
                    if (BG2[index + H] == BG2[index] && root != root2){
                        temp = Emp[root] + Emp[root2];
                        wqf.union(index, index + H);
                        root = wqf.find(index);
                        Emp[root] = temp;
                    }
                }
            }
        }

    }
    public boolean surrounded(int x, int y) // Answer if the stone and its connected stones are surrounded by another type of stones
    {
        return Emp[wqf.find(y * H + x)] == 0;
    }
    public int surroundNumber(int x, int y)
    {
        return Emp[wqf.find(y * H + x)];
    }
    public int root(int x, int y)
    {
        return wqf.find(y * H + x);
    }
    public int countConnectedRegions(){
        return wqf.count() - count;
    }// Get the number of connected regions in the board, including both types of the stones
    /*
    public static void test(String[] args){
        BoardGame g;
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(args[0])){
            JSONArray all = (JSONArray) jsonParser.parse(reader);
            int count = 0;
            for(Object CaseInList : all){
                count++;
                JSONArray a = (JSONArray) CaseInList;
                int testSize = 0; int waSize = 0;
                System.out.print("Case ");
                System.out.println(count);
                //Board Setup
                JSONObject argsSeting = (JSONObject) a.get(0);
                a.remove(0);

                JSONArray argSettingArr = (JSONArray) argsSeting.get("args");
                g = new BoardGame(
                        Integer.parseInt(argSettingArr.get(0).toString())
                        ,Integer.parseInt(argSettingArr.get(1).toString()));

                for (Object o : a)
                {
                    JSONObject person = (JSONObject) o;

                    String func =  person.get("func").toString();
                    JSONArray arg = (JSONArray) person.get("args");

                    switch(func){
                        case "putStone":
                            int xArray[] = JSONArraytoIntArray((JSONArray) arg.get(0));
                            int yArray[] = JSONArraytoIntArray((JSONArray) arg.get(1));
                            String stonetype =  (String) arg.get(2);

                            g.putStone(xArray,yArray,stonetype.charAt(0));
                            break;
                        case "surrounded":
                            Boolean answer = (Boolean) person.get("answer");
                            testSize++;
                            System.out.print(testSize + ": " + func + " / ");
                            Boolean ans = g.surrounded(
                                    Integer.parseInt(arg.get(0).toString()),
                                    Integer.parseInt(arg.get(1).toString())
                            );
                            if(ans==answer){
                                System.out.println("AC");
                            }else{
                                waSize++;
                                System.out.println("WA");
                            }
                            break;
                        case "countConnectedRegions":
                            testSize++;
                            int ans2 = Integer.parseInt(arg.get(0).toString());
                            int ansCR = g.countConnectedRegions();
                            System.out.print(testSize + ": " + func + " / ");
                            if(ans2==ansCR){
                                System.out.println("AC");
                            }else{
                                waSize++;
                                System.out.println("WA");
                            }
                    }

                }
                System.out.println("Score: " + (testSize-waSize) + " / " + testSize + " ");
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    public static int[] JSONArraytoIntArray(JSONArray x){
        int sizeLim = x.size();
        int MyInt[] = new int[sizeLim];
        for(int i=0;i<sizeLim;i++){
            MyInt[i]= Integer.parseInt(x.get(i).toString());
        }
        return MyInt;
    }

     */


    public static void main(String[] args){

        //test(args);
        /*
        BoardGame g = new BoardGame(11,11);
        g.putStone(new int[]{3,3,4,4,5,5,6,6,7,7,7}, new int[]{5,6,7,8,5,9,5,9,6,7,8}, 'X');
        g.putStone(new int[]{4,5,5,5,6,6,7}, new int[]{9,7,8,10,8,10,9}, 'O');
        g.putStone(new int[]{4,4,5,6,6}, new int[]{5,6,6,6,7}, 'O');
        g.putStone(new int[]{0,1,1,2,2,3,4,4,5,5,5}, new int[]{2,1,3,1,4,0,0,3,1,2,4}, 'X');
        g.putStone(new int[]{0,1,2,3,3,4,4,4}, new int[]{1,2,2,1,2,1,2,4}, 'O');
        System.out.println(g.surrounded(3,1));
        System.out.println(g.surroundNumber(3,1));
        System.out.println(g.root(3,1));

        System.out.println(g.surrounded(3,4));
        System.out.println(g.surroundNumber(3,4));
        System.out.println(g.root(3,4));

        System.out.println(g.surrounded(4,4));
        System.out.println(g.surroundNumber(4,4));
        System.out.println(g.surrounded(4,5));
        System.out.println(g.surroundNumber(4,5));

        g.putStone(new int[]{4}, new int[]{4}, 'O');
        System.out.println(g.surrounded(3,1));
        System.out.println(g.surroundNumber(3,1));
        System.out.println(g.root(3,1));
        System.out.println(g.surrounded(3,4));
        System.out.println(g.surroundNumber(3,4));
        System.out.println(g.root(3,4));

        System.out.println(g.surrounded(4,4));
        System.out.println(g.surroundNumber(4,4));
        System.out.println(g.root(4,4));
        System.out.println(g.surrounded(4,5));
        System.out.println(g.surroundNumber(4,5));
        System.out.println(g.root(4,5));
        */

        /*
        BoardGame g = new BoardGame(3,3);
        g.putStone(new int[]{0,0,1},new int[]{0,1,0},'O');
        g.putStone(new int[]{1,2,2},new int[]{2,1,2},'O');

        System.out.println(g.surrounded(0,0));
        System.out.println(g.surroundNumber(0,0));
        System.out.println(g.root(0,0));
        System.out.println(g.surrounded(0,1));
        System.out.println(g.surroundNumber(0,1));
        System.out.println(g.root(0,1));
        System.out.println(g.surrounded(2,2));
        System.out.println(g.surroundNumber(2,2));
        System.out.println(g.root(2,2));
        System.out.println(g.countConnectedRegions());
        g.putStone(new int[]{1},new int[]{1},'O');
        System.out.println(g.surroundNumber(1,1));
        System.out.println(g.surroundNumber(2,2));
        System.out.println(g.countConnectedRegions());

        System.out.println(g.root(0,0));
        System.out.println(g.root(1,1));
        System.out.println(g.root(2,2));
         */

    }
}
