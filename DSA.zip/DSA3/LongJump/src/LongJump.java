/*
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
class test {
    public test(String[] args) {
        LongJump g;
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(args[0])) {
            JSONArray all = (JSONArray) jsonParser.parse(reader);
            int count = 0;
            for (Object CaseInList : all) {
                count++;
                JSONArray a = (JSONArray) CaseInList;
                int testSize = 0;
                int waSize = 0;
                System.out.print("Case ");
                System.out.println(count);
                //Board Setup
                JSONObject argsSetting = (JSONObject) a.get(0);
                a.remove(0);

                JSONArray argSettingArr = (JSONArray) argsSetting.get("args");

                int[] arr = new int[argSettingArr.size()];
                for (int k = 0; k < argSettingArr.size(); k++) {
                    arr[k] = (int) (long) argSettingArr.get(k);
                }
                g = new LongJump(arr);

                for (Object o : a) {
                    JSONObject person = (JSONObject) o;

                    String func = person.get("func").toString();
                    JSONArray arg = (JSONArray) person.get("args");

                    switch (func) {
                        case "addPlayer" -> g.addPlayer(Integer.parseInt(arg.get(0).toString()));
                        case "winnerDistances" -> {
                            testSize++;
                            Integer t_ans = (int) (long) person.get("answer");
                            Integer r_ans = g.winnerDistances(Integer.parseInt(arg.get(0).toString()),
                                    Integer.parseInt(arg.get(1).toString()));
                            if (t_ans.equals(r_ans)) {
                                System.out.println("winnerDistances : AC");
                            } else {
                                waSize++;
                                System.out.println("winnerDistances : WA");
                                System.out.println("Your answer : " + r_ans);
                                System.out.println("True answer : " + t_ans);
                            }
                        }
                    }

                }
                System.out.println("Score: " + (testSize - waSize) + " / " + testSize + " ");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
*/
class BST2{
    private BST2.Node root;             // root of BST
    private class Node {
        private int key;           // sorted by key
        private int val;         // associated data
        private int sum;            //sum
        private BST2.Node left, right;  // left and right subtrees
        private int size;          // number of nodes in subtree

        public Node(int key, int val, int size, int sum) {
            this.key = key;
            this.val = val;
            this.size = size;
            this.sum = sum;
        }
    }
    public BST2() {}
    public boolean isEmpty() {
        return size() == 0;
    }
    /*
    public boolean contains(int key) {
        if (key == null) throw new IllegalArgumentException("argument to contains() is null");
        return getValue(key) != null;
    }
    public int getValue(int key) {
        return getValue(root, key);
    }
    private int getValue(BST2.Node x, int key) {
        if (x == null) return null;
        if      (key < x.key) return getValue(x.left, key);
        else if (key > x.key) return getValue(x.right, key);
        else              return x.val;
    }
     */
    public int size() {
        return size(root);
    }
    private int size(BST2.Node x) {
        if (x == null) return 0;
        else return x.size;
    }
    public int sum(){
        return sum(root);
    }
    private int sum(BST2.Node x){
        if (x == null) return 0;
        else return x.sum;
    }
    public void put(int key, int val) {
        root = put(root, key, val);
    }
    private BST2.Node put(BST2.Node x, int key, int val) {
        if (x == null) return new BST2.Node(key, val, 1, val);
        if      (key < x.key) x.left  = put(x.left,  key, val);
        else if (key > x.key) x.right = put(x.right, key, val);
        else              x.val   = val;
        x.size = 1 + size(x.left) + size(x.right);
        x.sum = x.val + sum(x.left) + sum(x.right);
        return x;
    }
    public int BtwRegion(int from, int to){
        return BtwRegion(root, from, to);
    }
    private int BtwRegion(BST2.Node x, int from, int to){
        if(x.key > to){//to 右邊
            /*
            if(x.left == null) return 0;
            else {
                if (x.left.key <= to) return BtwRegion(x.left, from, to);
                else return 0;
            }
             */
            if(x.left == null) return 0;
            return BtwRegion(x.left, from, to);
        }
        else if(x.key >= from){// from 和 to 中間 -> 擷取 Node 的 Value
            int a = 0, b = 0;
            int a1 = 0, a2 = 0;
            int b1 = 0, b2 = 0;
            if(x.left != null) {
                if (x.left.key >= from) {
                    if (x.left.right != null) a1 = x.left.right.sum;
                    if (x.left.left != null) a2 = BtwRegion(x.left.left, from ,to);
                    a = x.left.val + a1 + a2;
                }
                else a = BtwRegion(x.left, from, to);
            }
            if(x.right != null) {
                if(x.right.key <= to) {
                    if (x.right.left != null) b1 = x.right.left.sum;
                    if (x.right.right != null) b2 =BtwRegion(x.right.right, from, to);
                    b = x.right.val + b1 + b2;
                }
                else b = BtwRegion(x.right, from, to);
            }
            return x.val + a + b;
        }
        else{//from 左邊
            /*
            if(x.right == null) return 0;
            else {
                if (x.right.key >= from) return BtwRegion(x.right, from, to);
                    //else if(x.right.key == from) return x.right.key;
                else return 0;
            }
             */
            if(x.right == null) return 0;
            return BtwRegion(x.right, from, to);
        }
    }
    public int Search(int lo, int hi){
        return Search(root, lo, hi);
    }
    private int Search(BST2.Node x, int lo, int hi){
        if(x.key > hi){
            if(x.left == null) return 0;
            return Search(x.left ,lo ,hi);
        }
        if(x.key >= lo){
            int a = 0;
            int a1 = 0, a2 = 0;
            if(x.left != null)  {
                if(x.left.left != null) a1 = Search(x.left.left ,lo ,hi);
                if(x.left.right != null) a2 = size(x.left.right);
                a = 1 + a1 + a2;
            }
            int b = 0;
            int b1 = 0, b2 = 0;
            if(x.right != null) {
                if(x.right.right != null) b1 = Search(x.right.right ,lo ,hi);
                if(x.right.left != null) b2 = size(x.right.left);
                b = 1 + b1 + b2;
            }
            return 1 + a + b;
        }
        else{
            if(x.right == null) return 0;
            return Search(x.right, lo, hi);
        }
    }
}
class LongJump {
    BST2 BST2 = new BST2();
    private int iPlayer;
    public LongJump(int[] playerList){
        iPlayer = playerList.length;
        for(int i = 0; i < iPlayer; i++) BST2.put(playerList[i], playerList[i]);
    }
    public int sum(){
        return BST2.sum();
    }
    public void addPlayer(int distance) {
        BST2.put(distance, distance);
    }
    public int winnerDistances(int from, int to) {
        return BST2.BtwRegion(from, to);
    }
    public int numOfPlayers(int from, int to){
        return BST2.Search(from,to);
    }

    public static void main(String[] args) {
        //test t = new test(args);
        LongJump solution = new LongJump(new int[]{5,8,9,15});
        System.out.println(solution.winnerDistances(2,10));
        System.out.println(solution.numOfPlayers(2, 10));
        solution.addPlayer(10);
        solution.addPlayer(3);
        System.out.println(solution.winnerDistances(4,10));
        System.out.println(solution.numOfPlayers(4,10));
    }
}