import edu.princeton.cs.algs4.Stack;

import java.util.Arrays;
/*
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

 */



class warrior{
    int Strength;
    int Range;
    int Index;
    int max = 0;
    int min = 0;
    int[] c = new int[2];

    warrior(int str,int rng, int i){
        Strength=str;
        Range=rng;
        Index=i;
    }
}

class Warriors {
    public int[] warriors(int[] strength, int[] range) {
        int sz = strength.length;
        warrior[] sol = new warrior[sz];
        Stack<Integer> battle = new Stack<Integer>();
        Stack<Integer> battle2 = new Stack<Integer>();
        int[] d1 = new int[]{0, 0};
        int[] d = new int[2 * sz];

        if (sz == 1) {
            return d1;
        }
        else {
            for (int i = 0; i < sz; i++) {
                sol[i] = new warrior(strength[i], range[i], i);
            }
            //Peek Right
            for (int i = 0; i < sz; i++) {
                if(i == 0) battle.push(i);
                if(i > 0){
                    if(sol[i].Strength >= sol[battle.peek()].Strength){
                        while(true){
                            sol[battle.pop()].max = i - 1;
                            if(battle.size() != 0) {
                                if (sol[i].Strength < sol[battle.peek()].Strength) {
                                    battle.push(i);
                                    break;
                                }
                            }
                            if(battle.size() == 0){
                                battle.push(i);
                                break;
                            }
                        }
                    }
                    if (sol[i].Strength < sol[battle.peek()].Strength){
                        battle.push(i);
                    }
                }
                if (i == sz - 1){
                    while (!battle.isEmpty()){
                        sol[battle.pop()].max = i;
                        if(battle.isEmpty())break;
                    }
                }
            }
            for (int j = sz - 1 ; j > -1; j--){
                if (j == sz - 1) battle2.push(j);
                if (j < sz - 1){
                    if(sol[j].Strength >= sol[battle2.peek()].Strength){
                        while(true) {
                            sol[battle2.pop()].min = j + 1;
                            if(battle2.size() != 0) {
                                if (sol[j].Strength < sol[battle2.peek()].Strength) {
                                    battle2.push(j);
                                    break;
                                }
                            }
                            if(battle2.size() == 0){
                                battle2.push(j);
                                break;
                            }
                        }
                    }
                    if (sol[j].Strength < sol[battle2.peek()].Strength){
                        battle2.push(j);
                    }
                }
                if (j == 0){
                    while (!battle2.isEmpty()){
                        sol[battle2.pop()].min = j;
                        if(battle2.isEmpty())break;
                    }
                }
            }
            for (int k = 0; k < sz; k++){
                if (Math.abs(sol[k].max - k) > sol[k].Range) sol[k].max = k + sol[k].Range;
                if (Math.abs(sol[k].min - k) > sol[k].Range) sol[k].min = k - sol[k].Range;
                //sol[k].c[0] = Math.min(sol[k].max, k + sol[k].Range);
                //sol[k].c[1] = Math.max(sol[k].min, k - sol[k].Range);
                sol[k].c[0] = sol[k].min;
                sol[k].c[1] = sol[k].max;
                System.arraycopy(sol[k].c, 0, d, 2 * k, 2);
            }
            return d;
        }
    }

    public static void main(String[] args) {
       // test t = new test(args);
        /*
        Warriors sol = new Warriors();
        System.out.println(Arrays.toString(
                sol.warriors(new int[] {15, 3, 26, 2, 5, 19, 12, 8}
                        , new int[] { 1, 6, 1, 3, 2, 0, 1, 5})));
         */
    }

/*
    static class test {
        public test(String[] args) {
            Warriors sol = new Warriors();
            JSONParser jsonParser = new JSONParser();
            try (FileReader reader = new FileReader(args[0])) {
                JSONArray all = (JSONArray) jsonParser.parse(reader);
                for (Object CaseInList : all) {
                    JSONArray a = (JSONArray) CaseInList;
                    int q_cnt = 0, wa = 0, ac = 0;
                    for (Object o : a) {
                        q_cnt++;
                        JSONObject person = (JSONObject) o;
                        JSONArray arg_str = (JSONArray) person.get("strength");
                        JSONArray arg_rng = (JSONArray) person.get("attack_range");
                        JSONArray arg_ans = (JSONArray) person.get("answer");
                        int STH[] = new int[arg_str.size()];
                        int RNG[] = new int[arg_str.size()];
                        int Answer[] = new int[arg_ans.size()];
                        int Answer_W[] = new int[arg_ans.size()];
                        for (int i = 0; i < arg_ans.size(); i++) {
                            Answer[i] = (Integer.parseInt(arg_ans.get(i).toString()));
                            if (i < arg_str.size()) {
                                STH[i] = (Integer.parseInt(arg_str.get(i).toString()));
                                RNG[i] = (Integer.parseInt(arg_rng.get(i).toString()));
                            }
                        }
                        Answer_W = sol.warriors(STH, RNG);
                        for (int i = 0; i < arg_ans.size(); i++) {
                            if (Answer_W[i] == Answer[i]) {
                                if (i == arg_ans.size() - 1) {
                                    System.out.println(q_cnt + ": AC");
                                }
                            } else {
                                wa++;
                                System.out.println(q_cnt + ": WA");
                                break;
                            }
                        }

                    }
                    System.out.println("Score: " + (q_cnt - wa) + "/" + q_cnt);

                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
    */



}
