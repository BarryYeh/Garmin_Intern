import java.util.Arrays;
import java.util.PriorityQueue;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.Merge;
/*
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

class test{
    public test(String[] args){
        Kings sol;
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(args[0])){
            JSONArray all = (JSONArray) jsonParser.parse(reader);
            for(Object CaseInList : all){
                JSONArray a = (JSONArray) CaseInList;
                int q_cnt = 0, wa = 0,ac = 0;
                for (Object o : a) {
                    q_cnt++;
                    JSONObject person = (JSONObject) o;
                    JSONArray arg_str = (JSONArray) person.get("strength");
                    JSONArray arg_rng = (JSONArray) person.get("attack_range");
                    Long arg_k = (Long) person.get("k");
                    JSONArray arg_ans = (JSONArray) person.get("answer");
                    int STH[] = new int[arg_str.size()];
                    int RNG[] = new int[arg_str.size()];
                    int k = Integer.parseInt(arg_k.toString());

                    int Answer[] = new int[arg_ans.size()];
                    int Answer_W[] = new int[arg_ans.size()];
                    for(int i=0;i<arg_ans.size();i++){
                        Answer[i]=(Integer.parseInt(arg_ans.get(i).toString()));
                    }
                    for(int i=0;i<arg_str.size();i++){
                        STH[i]=(Integer.parseInt(arg_str.get(i).toString()));
                        RNG[i]=(Integer.parseInt(arg_rng.get(i).toString()));
                    }
                    sol = new Kings(STH,RNG);
                    Answer_W = sol.topKKings(k);
                    for(int i=0;i<arg_ans.size();i++){
                        if(Answer_W[i]==Answer[i]){
                            if(i==arg_ans.size()-1){
                                System.out.println(q_cnt+": AC");
                            }
                        }else {
                            wa++;
                            System.out.println(q_cnt+": WA");
                            break;
                        }
                    }

                }
                System.out.println("Score: "+(q_cnt-wa)+"/"+q_cnt);

            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
 */
class King implements Comparable<King>{
    // optional, for reference only
    int Strength;
    public int getStrength(){
        return Strength;
    }
    int Range;
    int Index;
    int min = 0;
    int max = 0;
    boolean Strong = true;
    int true_max = 0;
    int true_min = 0;
    King(int str,int rng, int i){
        Strength=str;
        Range=rng;
        Index=i;
    }
    public int compareTo(King compareStrength) {
        int compareQuantity = compareStrength.getStrength();
        return this.Strength - compareQuantity;
    }
}

class Kings {
    King[] TheKings;
    public static int ikings_n;
    public Kings(int[] strength, int[] range){
        // Given the attributes of each warrior
        ikings_n = strength.length;
        TheKings = new King[ikings_n];
        for ( int i = 0; i < ikings_n; i++){
            TheKings[i] = new King(strength[i], range[i], i);
        }
    }
    public int[] topKKings(int m) {
        Stack<Integer> battle_right = new Stack<Integer>();
        Stack<Integer> battle_left = new Stack<Integer>();
        int[] _iOneKing = new int[]{0};
        if (ikings_n == 0) return null;
        if (ikings_n == 1) return _iOneKing;
        else {
            //Peek Right
            for (int i = 0; i < ikings_n; i++) {
                if(i == 0) battle_right.push(i);
                if(i > 0){
                    if(TheKings[i].Strength >= TheKings[battle_right.peek()].Strength){
                        while(true){
                            int _right_pop = battle_right.pop();
                            TheKings[_right_pop].max = i - 1;
                            if(battle_right.size() != 0) {
                                if (TheKings[i].Strength < TheKings[battle_right.peek()].Strength) {
                                    battle_right.push(i);
                                    break;
                                }
                            }
                            if(battle_right.size() == 0){
                                battle_right.push(i);
                                break;
                            }
                        }
                    }
                    if (TheKings[i].Strength < TheKings[battle_right.peek()].Strength)
                        battle_right.push(i);
                }
                if (i == ikings_n - 1)
                    while (!battle_right.isEmpty())
                        TheKings[battle_right.pop()].max = i;
            }
            //Peek Left
            for (int j = ikings_n - 1 ; j > -1; j--){
                if (j == ikings_n - 1) battle_left.push(j);
                if (j < ikings_n - 1){
                    if(TheKings[j].Strength >= TheKings[battle_left.peek()].Strength){
                        while(true) {
                            int _left_pop = battle_left.pop();
                            TheKings[_left_pop].min = j + 1;
                            if(battle_left.size() != 0) {
                                if (TheKings[j].Strength < TheKings[battle_left.peek()].Strength) {
                                    battle_left.push(j);
                                    break;
                                }
                            }
                            if(battle_left.size() == 0){
                                battle_left.push(j);
                                break;
                            }
                        }
                    }
                    if (TheKings[j].Strength < TheKings[battle_left.peek()].Strength)
                        battle_left.push(j);
                }
                if (j == 0)
                    while (!battle_left.isEmpty())
                        TheKings[battle_left.pop()].min = 0;
            }
            for (int k = 0; k < ikings_n; k++) {
                TheKings[k].true_max = Math.min(TheKings[k].max, k + TheKings[k].Range);
                TheKings[k].true_min = Math.max(TheKings[k].min, k - TheKings[k].Range);
        }
            FindKings(TheKings);
            Stack<King> sTrue_Kings = new Stack<>();
            int s = 0;
            for(int a = 0; a < ikings_n; a++)
                if(TheKings[a].Strong)
                    sTrue_Kings.push(TheKings[a]);
            King[] kTrue_Kings = new King[sTrue_Kings.size()];
            while(!sTrue_Kings.isEmpty()) kTrue_Kings[s++] = sTrue_Kings.pop();
            Merge.sort(kTrue_Kings);
            if(s == 0) return null;
            else {
                if (m < s) {
                    int[] Ans_1 = new int[m];
                    for (int m_ = 0; m_ < m; m_++) Ans_1[m_] = kTrue_Kings[s - 1 - m_].Index;
                    return Ans_1;
                } else {
                    int[] Ans_2 = new int[s];
                    for (int _m = 0; _m < s; _m++) Ans_2[_m] = kTrue_Kings[s - 1 - _m].Index;
                    return Ans_2;
                }
            }

        }
        // complete the code by returning an int[]
        // remember to return the array of indexes in the descending order of strength
    }
        public void battle(King[] Soldiers, int lo, int hi){
            if(lo >= hi) return;
            int boss = (lo + hi) / 2;
            for(int i = 1; (boss + i) <= Soldiers[boss].true_max; i++) {
                Soldiers[boss + i].Strong = false;
            }
            for(int j = 1; (boss - j) >= Soldiers[boss].true_min; j++){
                Soldiers[boss - j].Strong = false;
            }
            int boss_right = Soldiers[boss].true_max + 1;
            int boss_left = Soldiers[boss].true_min - 1;
            battle(Soldiers, boss_right, hi);
            battle(Soldiers, lo, boss_left);
        }
        public void FindKings(King[] Soldiers){
            battle(Soldiers, 0, Soldiers.length - 1);
        }
    public static void main(String[] args) {
        //test t = new test(args);
        /*
        Kings sol = new Kings(new int[] {15, 3, 26, 2, 5, 19, 12, 8}
                , new int[] { 1, 6, 1, 3, 2, 0, 1, 5});
        System.out.println(Arrays.toString(sol.topKKings(3)));
         */
        // In this case, the kings are [0, 2, 4, 5, 6] (without sorting, only by the order of ascending indices)
        // Output: [2, 5, 0]
    }
}