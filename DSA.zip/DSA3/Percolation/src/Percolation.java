import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
/*
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
*/
class Percolation {
    private WeightedQuickUnionUF connection;
    private WeightedQuickUnionUF reservoir;
    private WeightedQuickUnionUF path;
    private boolean isPercolated = false;
    private boolean[] Opened;
    public int n;
    private int lastx;
    private int lasty;
    private static class Node {
        private Point2D site;
        private Node next;
    }
    public Percolation(int N){
        n = N;
        connection = new WeightedQuickUnionUF(N * N + 2);
        reservoir = new WeightedQuickUnionUF(N * N + 1);
        path = new WeightedQuickUnionUF(N * N + 1);
        Opened = new boolean[N * N + 1];
        for(int  i = 0; i < N ; i++)
            for(int j = 0; j < N; j++)
                Opened[i * N + j + 1] = false;
    }// create N-by-N grid, with all sites blocked
    public void open(int i, int j){
        int index = i * n + j + 1;
        if(!Opened[index])
            Opened[index] = true;
        if(i == 0){
            //if(!connection.connected(index, 0))
            connection.union(index, 0);
            //if(!reservoir.connected(index, 0))
            reservoir.union(index, 0);
        }
        if(i == n - 1)
            //if(!connection.connected(index, n+1))
            connection.union(index, n*n + 1);
        if(j != 0)
            if(Opened[index - 1]) {
                //if(!connection.connected(index, index - 1))
                connection.union(index, index - 1);
                //if(!reservoir.connected(index, index - 1))
                reservoir.union(index, index - 1);
                if(!isPercolated)
                    path.union(index, index - 1);
            }
        if(j != n - 1)
            if(Opened[index + 1]) {
                //if(!connection.connected(index, index + 1))
                connection.union(index, index + 1);
                //if(!reservoir.connected(index, index + 1))
                reservoir.union(index, index + 1);
                if(!isPercolated)
                    path.union(index, index + 1);
            }
        if(i != 0)
            if(Opened[index - n]) {
                //if(!connection.connected(index, index - n))
                connection.union(index, index - n);
                //if(!reservoir.connected(index, index - n))
                reservoir.union(index, index - n);
                if(!isPercolated)
                    path.union(index, index - n);
            }
        if(i != n-1)
            if(Opened[index + n]) {
                //if(!connection.connected(index, index + n))
                connection.union(index, index + n);
                //if(!reservoir.connected(index, index + n))
                reservoir.union(index, index + n);
                if(!isPercolated)
                    path.union(index, index + n);
            }
        if (!isPercolated) {
            lastx = i;
            lasty = j;
            if(percolates())
                isPercolated = true;
        }
        /*
        if (!percolates()) {
            lastx = i;
            lasty = j;
        }
         */
    }// open site (row i, column j) if it is not open already
    public boolean isOpen(int i, int j){
        return Opened[i * n + j + 1];
    }// is site (row i, column j) open?
    public boolean isFull(int i, int j){
        return reservoir.find(i * n + j + 1) == reservoir.find(0);
    }// is site (row i, column j) full?
    public boolean percolates(){
        return connection.find(0) == connection.find(n*n+1);
    }// does the system percolate?
    public int rootConnection(int n){
        return connection.find(n);
    }
    public int rootConnection(int i, int j){
        return connection.find(i * n + j + 1);
    }
    public Point2D[] PercolatedRegion() {
        Stack<Point2D> Points = new Stack<Point2D>();
        int record = 0;
        int a = path.find(lastx * n + lasty + 1);
        if(!percolates()) return null;
        for(int j = n-1; j >= 0; j--) {
            for (int i = n-1; i >= 0; i--) {
                int index = i * n + j + 1;
                if(path.find(index) == a) {
                    Points.push(new Point2D(i, j));
                    record++;
                }
            }
        }
        Point2D[] Ans = new Point2D[record];
        for(int i = 0; i < record; i++)
            Ans[i] = Points.pop();
        return Ans;
    }// print the sites of the percolated region in order
    /*
    public static void test(String[] args){
        Percolation g;
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(args[0])){
            JSONArray all = (JSONArray) jsonParser.parse(reader);
            int count = 0;
            for(Object CaseInList : all){
                count++;
                JSONArray a = (JSONArray) CaseInList;
                int testSize = 0; int waSize = 0;
                System.out.print("Case ");
                System.out.println(count);
                //Board Setup
                JSONObject argsSeting = (JSONObject) a.get(0);
                a.remove(0);

                JSONArray argSettingArr = (JSONArray) argsSeting.get("args");
                g = new Percolation(
                        Integer.parseInt(argSettingArr.get(0).toString()));

                for (Object o : a)
                {
                    JSONObject person = (JSONObject) o;

                    String func =  person.get("func").toString();
                    JSONArray arg = (JSONArray) person.get("args");

                    switch(func){
                        case "open":
                            g.open(Integer.parseInt(arg.get(0).toString()),
                                    Integer.parseInt(arg.get(1).toString()));
                            break;
                        case "isOpen":
                            testSize++;
                            String true_isop = (Boolean)person.get("answer")?"1":"0";
                            String ans_isop = g.isOpen(Integer.parseInt(arg.get(0).toString()),
                                    Integer.parseInt(arg.get(1).toString()))?"1":"0";
                            if(true_isop.equals(ans_isop)){
                                System.out.println("isOpen : AC");
                            }else{
                                waSize++;
                                System.out.println("isOpen : WA");
                            }
                            break;
                        case "isFull":
                            testSize++;
                            String true_isfu =  (Boolean)person.get("answer")?"1":"0";
                            String ans_isfu = g.isFull(Integer.parseInt(arg.get(0).toString()),
                                    Integer.parseInt(arg.get(1).toString()))?"1":"0";
                            if(true_isfu.equals(ans_isfu)){
                                System.out.println("isFull : AC");
                            }else{
                                waSize++;
                                System.out.println("isFull : WA");
                            }
                            break;
                        case "percolates":
                            testSize++;
                            String true_per = (Boolean)person.get("answer")?"1":"0";
                            String ans_per = g.percolates()?"1":"0";
                            if(true_per.equals(ans_per)){
                                System.out.println("percolates : AC");
                            }else{
                                waSize++;
                                System.out.println("percolates : WA");
                            }
                            break;
                        case "PercolatedRegion":
                            testSize++;
                            String true_reg = person.get("args").toString();
                            String reg = "[";
                            Point2D[] pr = g.PercolatedRegion();
                            for (int i = 0; i < pr.length; i++) {
                                reg = reg + ((int)pr[i].x() + "," + (int)pr[i].y());
                                if(i != pr.length - 1){
                                    reg =reg + ",";
                                }
                            }
                            reg = reg +"]";
                            if(true_reg.equals(reg)){
                                System.out.println("PercolatedRegion : AC");
                            }else{
                                waSize++;
                                System.out.println("PercolatedRegion : WA");
                            }
                            break;
                    }

                }
                System.out.println("Score: " + (testSize-waSize) + " / " + testSize + " ");
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
*/
    public static void main(String args[]) {
        //test(args);
        /*
        Percolation s = new Percolation(3);
        s.open(0,2);
        s.open(1,2);
        s.open(2,2);
        s.open(2, 1);
        s.open(2, 0);
        Point2D[] pr = s.PercolatedRegion();
        for (int i = 0; i < pr.length; i++) {
            System.out.println("(" + (int) pr[i].x() + "," + (int) pr[i].y() + ")");
        }
        */
    }
}