import java.util.*;
import java.lang.Math;
/*
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class test{
    public test(String[] args){
        Cluster sol = new Cluster();
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(args[0])){
            JSONArray all = (JSONArray) jsonParser.parse(reader);
            for(Object CaseInList : all){
                JSONArray a = (JSONArray) CaseInList;
                int q_cnt = 0, wa = 0,ac = 0;
                for (Object o : a) {
                    q_cnt++;
                    JSONObject person = (JSONObject) o;
                    JSONArray point = (JSONArray) person.get("points");
                    Long clusterNumber = (Long) person.get("cluster_num");
                    JSONArray arg_ans = (JSONArray) person.get("answer");
                    int points_x[] = new int[point.size()];
                    int points_y[] = new int[point.size()];
                    double Answer_x[] = new double[arg_ans.size()];
                    double Answer_y[] = new double[arg_ans.size()];
                    List<double[]> ansClus = new ArrayList<double[]>();
                    ArrayList<int[]> pointList = new ArrayList<int[]>();
                    for(int i=0;i<clusterNumber;i++){
                        String ansStr = arg_ans.get(i).toString();
                        ansStr = ansStr.replace("[","");ansStr = ansStr.replace("]","");
                        String[] parts = ansStr.split(",");
                        Answer_x[i] = Double.parseDouble(parts[0]);
                        Answer_y[i] = Double.parseDouble(parts[1]);
                    }
                    for(int i=0;i< point.size();i++){
                        String ansStr = point.get(i).toString();
                        ansStr = ansStr.replace("[","");ansStr = ansStr.replace("]","");
                        String[] parts = ansStr.split(",");
                        pointList.add(new int[]{Integer.parseInt(parts[0]),Integer.parseInt(parts[1])});
                    }
                    ansClus = sol.cluster(pointList,Integer.parseInt(clusterNumber.toString()));
                    if(ansClus.size()!=clusterNumber){
                        wa++;
                        System.out.println(q_cnt+": WA");
                        break;
                    } else{
                        for(int i=0;i<clusterNumber;i++){
                            if(ansClus.get(i)[0]!=Answer_x[i] || ansClus.get(i)[1]!=Answer_y[i]){
                                wa++;
                                System.out.println(q_cnt+": WA");
                                break;
                            }
                        }
                        System.out.println(q_cnt+": AC");
                    }
                }
                System.out.println("Score: "+(q_cnt-wa)+"/"+q_cnt);

            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}

 */
class Point implements Comparable<Point> {
    boolean isMerged;
    int Weight;
    double x;
    public double x() {return x;}
    double y;
    public double y() {return y;}

    public static final Comparator<Point> X_ORDER = new Point.XOrder();
    public static final Comparator<Point> Y_ORDER = new Point.YOrder();

    public boolean equals(Object other) {
        if (other == this) return true;
        if (other == null) return false;
        if (other.getClass() != this.getClass()) return false;
        Point that = (Point) other;
        return this.x == that.x && this.y == that.y;
    }
    private static class XOrder implements Comparator<Point> {
        public int compare(Point p, Point q) {
            if (p.x < q.x) return -1;
            if (p.x > q.x) return +1;
            return 0;
        }
    }
    // compare points according to their y-coordinate
    private static class YOrder implements Comparator<Point> {
        public int compare(Point p, Point q) {
            if (p.y < q.y) return -1;
            if (p.y > q.y) return +1;
            return 0;
        }
    }
    public static final Comparator<Point> ORDER = new Point.Order();
    private static class Order implements Comparator<Point> {
        public int compare(Point p, Point q) {
            if (p.x < q.x) return -1;
            else if (p.x > q.x) return +1;
            else{
                if (p.y < q.y) return -1;
                if (p.y > q.y) return +1;
            }
            return 0;
        }
    }
    public static final Comparator<Point> MERGE_ORDER = new Point.Order();
    private static class MERGE_Order implements Comparator<Point> {
        public int compare(Point p, Point q) {
            if (p.x < q.x) return -1;
            else if (p.x > q.x) return +1;
            else{
                if (p.y < q.y) return -1;
                if (p.y > q.y) return +1;
            }
            return 0;
        }
    }
    public Point(double x, double y, int weight, boolean merged){
        //this.Index = index;
        this.isMerged = merged;
        this.Weight = weight;
        if (x == 0.0) this.x = 0.0;  // convert -0.0 to +0.0
        else          this.x = x;

        if (y == 0.0) this.y = 0.0;  // convert -0.0 to +0.0
        else          this.y = y;
    }
    public int compareTo(Point that) {
        if (this.y < that.y) return -1;
        if (this.y > that.y) return +1;
        if (this.x < that.x) return -1;
        if (this.x > that.x) return +1;
        return 0;
    }
    public double distanceTo2(Point that) {
        double dx = this.x - that.x;
        double dy = this.y - that.y;
        return dx*dx + dy*dy;
    }
}
class Distance implements Comparable<Distance>{
    Point To;
    Point From;
    double Distance;
    public double distance(Point from, Point to){
        return from.distanceTo2(to);
    }
    @Override
    public int compareTo(Distance that) {
        if(this.Distance > that.Distance) return 1;
        if(this.Distance < that.Distance) return -1;
        return 0;
    }
}
class ClosestPair{
    private Point best1, best2;
    private double bestDistance = Double.POSITIVE_INFINITY;

    public ClosestPair(Point[] points) {
        if (points == null) throw new IllegalArgumentException("constructor argument is null");
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) throw new IllegalArgumentException("array element " + i + " is null");
        }

        int n = points.length;
        if (n <= 1) return;

        // sort by x-coordinate (breaking ties by y-coordinate via stability)
        Point[] pointsByX = new Point[n];
        System.arraycopy(points, 0, pointsByX, 0, n);
        Arrays.sort(pointsByX, Point.Y_ORDER);
        Arrays.sort(pointsByX, Point.X_ORDER);

        // check for coincident points
        for (int i = 0; i < n && !pointsByX[i].isMerged; i++) {
            int l = 1;
            while (pointsByX[i+l].isMerged) {
                l++;
                if(i + l >= n) break;
            }
            if (pointsByX[i].equals(pointsByX[i+l])) {
                bestDistance = 0.0;
                best1 = pointsByX[i];
                best2 = pointsByX[i+l];
                return;
            }
        }

        // sort by y-coordinate (but not yet sorted)
        Point[] pointsByY = new Point[n];
        System.arraycopy(pointsByX, 0, pointsByY, 0, n);

        // auxiliary array
        Point[] aux = new Point[n];

        closest(pointsByX, pointsByY, aux, 0, n-1);
    }
    private double closest(Point[] pointsByX, Point[] pointsByY, Point[] aux, int lo, int hi) {
        if (hi <= lo) return Double.POSITIVE_INFINITY;

        int mid = lo + (hi - lo) / 2;
        while(pointsByX[mid].isMerged){
            mid++;
        }
        Point median = pointsByX[mid];


        // compute closest pair with both endpoints in left sub-array or both in right sub-array
        double delta1 = closest(pointsByX, pointsByY, aux, lo, mid);
        double delta2 = closest(pointsByX, pointsByY, aux, mid+1, hi);
        double delta = Math.min(delta1, delta2);

        // merge back so that pointsByY[lo..hi] are sorted by y-coordinate
        merge(pointsByY, aux, lo, mid, hi);

        // aux[0..m-1] = sequence of points closer than delta, sorted by y-coordinate
        int m = 0;
        for (int i = lo; i <= hi && !pointsByY[i].isMerged; i++) {
            if (Math.abs(pointsByY[i].x() - median.x()) < delta)
                aux[m++] = pointsByY[i];
        }

        // compare each point to its neighbors with y-coordinate closer than delta
        for (int i = 0; i < m; i++) {
            while(aux[i].isMerged) i++;
            // a geometric packing argument shows that this loop iterates at most 7 times
            for (int j = i+1; (j < m); j++) {
                while(aux[j].isMerged) j++;
                if((aux[j].y() - aux[i].y())*(aux[j].y() - aux[i].y()) < delta) {
                    double distance = aux[i].distanceTo2(aux[j]);
                    if (distance < delta) {
                        delta = distance;
                        if (distance < bestDistance) {
                            bestDistance = delta;
                            best1 = aux[i];
                            best2 = aux[j];
                            //StdOut.println("better distance = " + delta + " from " + best1 + " to " + best2);
                        }
                    }
                }
            }
        }
        return delta;
    }
    public Point either() {
        return best1;
    }
    public Point other() {
        return best2;
    }
    public double distance() {
        return Math.sqrt(bestDistance);
    }
    private static boolean less(Point v, Point w) {
        return v.compareTo(w) < 0;
    }

    private static void merge(Point[] a, Point[] aux, int lo, int mid, int hi) {
        // copy to aux[]
        for (int k = lo; k <= hi; k++) {
            aux[k] = a[k];
        }
        // merge back to a[]
        int i = lo, j = mid+1;
        for (int k = lo; k <= hi; k++) {
            if      (i > mid)              a[k] = aux[j++];
            else if (j > hi)               a[k] = aux[i++];
            else if (less(aux[j], aux[i])) a[k] = aux[j++];
            else                           a[k] = aux[i++];
        }
    }
}
class Cluster {
    List<Point> test = new ArrayList<Point>();
    Cluster() {}
    public List<double[]> cluster(List<int[]> points, int cluster_num) {
        ArrayList<Point> p = new ArrayList<Point>();
        for (int[] i : points) {
            p.add(new Point(i[0], i[1], 1, false));
        }
        RemainCluster(p, cluster_num);
        p.sort(Point.ORDER);
        ArrayList<double[]> ans = new ArrayList<double[]>();
        for (Point j : p) {
            if (!j.isMerged)
                ans.add(new double[]{j.x, j.y});
        }
        return ans;
    }

    private void RemainCluster(ArrayList<Point> P, int P_num) {
        if (P.size() <= P_num) return;
        int P_index = 0;
        Point[] p = new Point[P.size()];
        for (Point i : P) {
            p[P_index] = i;
            P_index++;
        }
        ClosestPair c = new ClosestPair(p);
        int mergeW = c.either().Weight + c.other().Weight;
        double mergeX = (c.either().x * c.either().Weight + c.other().x * c.other().Weight) / mergeW;
        double mergeY = (c.either().y * c.either().Weight + c.other().y * c.other().Weight) / mergeW;
        c.either().isMerged = true;
        c.other().isMerged = true;
        P.add(new Point(mergeX, mergeY, mergeW, false));
        RemainCluster(P, P_num);
    }

    public static void main(String[] args) {

        //test t = new test(args);
        List<double[]> out = new Cluster().cluster(new ArrayList<int[]>(){{
            add(new int[]{65,28});
            add(new int[]{76,1});
            add(new int[]{52,50});
            add(new int[]{33,30});
            add(new int[]{84,8});
            add(new int[]{35,61});
            add(new int[]{71,61});
            add(new int[]{46,87});
            add(new int[]{11,47});
            add(new int[]{10,80});
            add(new int[]{1,24});
            add(new int[]{29,31});
            add(new int[]{51,85});
            add(new int[]{98,3});
            add(new int[]{61,34});
            add(new int[]{19,13});
            add(new int[]{8,86});
            add(new int[]{21,73});
            add(new int[]{86,60});
            add(new int[]{10,53});
        }}, 5);
        for(double[] o: out)
            System.out.println(Arrays.toString(o));
        //Ans: [0.0, 1.5] [3.0, 1.5]


    }
}